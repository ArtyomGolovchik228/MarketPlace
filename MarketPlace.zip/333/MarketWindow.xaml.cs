using System.Windows;

namespace MarketplaceApp
{
    public partial class MarketWindow : Window
    {
        public MarketWindow()
        {
            InitializeComponent();
        }
    }
}