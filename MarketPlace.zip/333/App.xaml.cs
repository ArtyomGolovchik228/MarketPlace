using System.Windows;

namespace MarketplaceApp
{
    public partial class App : Application
    {
    }
}
