using _333;
using MarketplaceApp.ViewModels;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace MarketplaceApp
{
    public partial class MainWindow : Window
    {
        private List<Products> cart = new List<Products>();

        public MainWindow()
        {
            InitializeComponent();
            LoadProducts();
        }

        private void LoadProducts()
        {
            using (var db = new MarketplaceDBEntities())
            {
                ProductsDataGrid.ItemsSource = db.Products.ToList();
            }
        }

        private void AddToCart_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsDataGrid.SelectedItem is Products selectedProduct)
            {
                cart.Add(selectedProduct);
                MessageBox.Show($"Товар \"{selectedProduct.Name}\" добавлен в корзину.");
            }
        }

        private void OpenCart_Click(object sender, RoutedEventArgs e)
        {
            var cartWindow = new CartWindow(cart.Select(p => new ProductViewModel
            {
                ProductId = p.ProductId,
                Name = p.Name,
                Price = p.Price ?? 0m  // если Price — decimal?
            }).ToList());

            cartWindow.ShowDialog();
        }
    }
}