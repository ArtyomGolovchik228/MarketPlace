using System.Windows;

namespace WPFMarketplaceApp.Views
{
    public partial class MarketWindow : Window
    {
        public MarketWindow()
        {
            InitializeComponent();
        }
    }
}
