using MarketplaceApp.ViewModels;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace MarketplaceApp
{
    public partial class CartWindow : Window
    {
        private List<ProductViewModel> cartItems;

        public CartWindow(List<ProductViewModel> items)
        {
            InitializeComponent();
            cartItems = items;
            CartDataGrid.ItemsSource = cartItems;
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (CartDataGrid.SelectedItem is ProductViewModel selectedItem)
            {
                cartItems.Remove(selectedItem);
                CartDataGrid.ItemsSource = null;
                CartDataGrid.ItemsSource = cartItems;
            }
            else
            {
                MessageBox.Show("Выберите товар для удаления.", "Внимание");
            }
        }

        private void CheckoutButton_Click(object sender, RoutedEventArgs e)
        {
            if (!cartItems.Any())
            {
                MessageBox.Show("Корзина пуста.");
                return;
            }

            var orderWindow = new OrderWindow(cartItems);
            orderWindow.ShowDialog();
            this.Close();
        }
    }
}
