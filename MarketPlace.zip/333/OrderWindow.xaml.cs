using MarketplaceApp.ViewModels;
using System.Collections.Generic;
using System.Windows;

namespace MarketplaceApp
{
    public partial class OrderWindow : Window
    {
        public OrderWindow(List<ProductViewModel> cartItems)
        {
            InitializeComponent();

            // Здесь можно реализовать сохранение заказа в БД при необходимости
        }
    }
}
